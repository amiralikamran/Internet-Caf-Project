/* ===== تنظیمات ===== */
const K={orders:'cafenet_orders',pass:'cafenet_admin_cred',phones:'cafenet_phones',fails:'cafenet_login_fails'};
const MAX_FILE=2*1024*1024, MAX_FILES=5, MAX_TEXT=20000;
const MAX_STRIKES=2;      // بعد از این تعداد نیامدن، شماره مسدود می‌شود
const GRACE_MIN=15;       // مهلت اضافه بعد از زمان انتخابی مشتری
const ACTIVE_LIMIT=1;     // سفارش منتظر هم‌زمان برای هر شماره
const HOURLY_LIMIT=3;     // حداکثر سفارش در هر ساعت برای هر شماره
const IDLE_MS=15*60*1000; // خروج خودکار مدیر بعد از بی‌کاری
const ALLOWED=['image/png','image/jpeg','image/webp','image/gif','application/pdf','text/plain','application/msword','application/vnd.openxmlformats-officedocument.wordprocessingml.document'];
const STATUS={pending:'منتظر حضور مشتری',arrived:'مشتری آمده',printing:'در حال چاپ',ready:'آماده تحویل',done:'تحویل شد',expired:'منقضی شد',noshow:'نیامد'};

/* ===== ابزار ===== */
const $=s=>document.querySelector(s);
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const load=(k,d)=>{try{return JSON.parse(localStorage.getItem(k))??d}catch{return d}};
const store=(k,v)=>localStorage.setItem(k,JSON.stringify(v));
const digits=s=>String(s).replace(/[۰-۹]/g,d=>'۰۱۲۳۴۵۶۷۸۹'.indexOf(d)).replace(/[٠-٩]/g,d=>'٠١٢٣٤٥٦٧٨٩'.indexOf(d)).replace(/\D/g,'');
const readFile=f=>new Promise((res,rej)=>{const r=new FileReader();r.onload=()=>res({name:f.name,type:f.type,data:r.result});r.onerror=rej;r.readAsDataURL(f)});
const db={orders:()=>load(K.orders,[]),save:l=>store(K.orders,l),phones:()=>load(K.phones,{}),savePhones:p=>store(K.phones,p)};

/* ===== قانون نیامدن و مسدودسازی ===== */
function strike(phone){
  const p=db.phones(); const r=p[phone]||(p[phone]={strikes:0,blocked:false});
  r.strikes++; if(r.strikes>=MAX_STRIKES) r.blocked=true; db.savePhones(p);
}
function expireOverdue(){
  const l=db.orders(); let changed=false;
  l.forEach(o=>{if(o.status==='pending'&&Date.now()>o.expiresAt){o.status='expired';strike(o.phone);changed=true}});
  if(changed) db.save(l);
}

/* ===== صفحه مشتری ===== */
const form=$('#orderForm');
if(form){
  const input=$('#files'), list=$('#fileList');
  input.addEventListener('change',()=>{list.innerHTML=[...input.files].map(f=>`<li>${esc(f.name)} (${Math.ceil(f.size/1024)} کیلوبایت)</li>`).join('')});
  form.addEventListener('submit',async e=>{
    e.preventDefault(); expireOverdue();
    const out=$('#result'), fd=new FormData(form), text=fd.get('text').trim(), fl=[...input.files];
    const show=(c,h)=>{out.className='msg '+c;out.innerHTML=h};
    if(fd.get('website')) return show('ok','سفارش ثبت شد.'); // ربات: بی‌صدا نادیده گرفته می‌شود
    const phone=digits(fd.get('phone'));
    if(!/^09\d{9}$/.test(phone)) return show('err','شماره موبایل را درست وارد کنید. مثال: 09123456789');
    if(db.phones()[phone]?.blocked) return show('err','این شماره مسدود شده است. برای رفع مسدودی حضوری به کافی‌نت مراجعه کنید.');
    const mine=db.orders().filter(o=>o.phone===phone);
    if(mine.filter(o=>o.status==='pending').length>=ACTIVE_LIMIT) return show('err','سفارش قبلی شما هنوز منتظر حضور شماست. اول آن را تحویل بگیرید یا صبر کنید تا مهلتش تمام شود.');
    if(mine.filter(o=>Date.now()-o.at<3600e3).length>=HOURLY_LIMIT) return show('err','تعداد سفارش در یک ساعت از حد مجاز بیشتر شده است. بعداً دوباره تلاش کنید.');
    if(!text&&!fl.length) return show('err','متن بنویسید یا حداقل یک فایل انتخاب کنید.');
    if(text.length>MAX_TEXT) return show('err','متن خیلی طولانی است. از آپلود فایل استفاده کنید.');
    if(fl.length>MAX_FILES) return show('err',`حداکثر ${MAX_FILES} فایل مجاز است.`);
    if(fl.some(f=>f.size>MAX_FILE)) return show('err','حجم هر فایل باید کمتر از ۲ مگابایت باشد.');
    if(fl.some(f=>!ALLOWED.includes(f.type))) return show('err','نوع فایل مجاز نیست. فقط عکس، PDF، Word و متن.');
    try{
      const files=await Promise.all(fl.map(readFile));
      const eta=+fd.get('eta')||30, now=Date.now();
      const order={id:now.toString(36),code:String(Math.floor(1000+Math.random()*9000)),
        name:fd.get('name').trim().slice(0,60),phone,copies:Math.max(1,Math.min(500,+fd.get('copies')||1)),
        color:fd.get('color')==='color'?'color':'bw',size:['A4','A5','A3'].includes(fd.get('size'))?fd.get('size'):'A4',
        sides:fd.get('sides')==='2'?'2':'1',note:fd.get('note').trim().slice(0,300),
        text,files,status:'pending',at:now,expiresAt:now+(eta+GRACE_MIN)*60000};
      const l=db.orders(); l.unshift(order); db.save(l);
      form.reset(); list.innerHTML='';
      const until=new Date(order.expiresAt).toLocaleTimeString('fa-IR',{hour:'2-digit',minute:'2-digit'});
      show('ok',`سفارش ثبت شد. کد پیگیری شما: <span class="code">${order.code}</span><br>تا ساعت ${until} به کافی‌نت بیایید و این کد را بگویید تا چاپ شروع شود. اگر نیایید، سفارش لغو می‌شود.`);
    }catch{show('err','ثبت سفارش انجام نشد. حافظه مرورگر پر است یا فایل‌ها خیلی بزرگ‌اند.')}
  });
}

/* ===== پنل مدیریت ===== */
const login=$('#login');
if(login){
  const secure=!!(window.crypto&&crypto.subtle);
  const sha=async(s,salt)=>[...new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(salt+s)))].map(b=>b.toString(16).padStart(2,'0')).join('');
  const newSalt=()=>[...crypto.getRandomValues(new Uint32Array(4))].join('-');
  const authed=()=>sessionStorage.getItem('cn_admin')==='1';
  let idle;
  const touch=()=>{clearTimeout(idle);if(authed())idle=setTimeout(()=>{sessionStorage.removeItem('cn_admin');gate()},IDLE_MS)};
  ['click','keydown','pointermove'].forEach(ev=>addEventListener(ev,touch));
  function gate(){
    const setup=!load(K.pass,null);
    $('#loginTitle').textContent=setup?'ساخت رمز مدیریت (بار اول)':'ورود مدیریت';
    $('#pass2Box').hidden=!setup; $('#login').hidden=authed(); $('#panel').hidden=!authed();
    if(authed()){render();touch()}
  }
  login.addEventListener('submit',async e=>{
    e.preventDefault(); const err=$('#loginErr'); err.textContent='';
    if(!secure) return err.textContent='این صفحه باید با HTTPS یا localhost باز شود.';
    const p=$('#pass').value, c=load(K.pass,null);
    if(!c){
      if(p.length<6) return err.textContent='رمز باید حداقل ۶ کاراکتر باشد.';
      if(p!==$('#pass2').value) return err.textContent='تکرار رمز یکسان نیست.';
      const salt=newSalt(); store(K.pass,{salt,hash:await sha(p,salt)});
      sessionStorage.setItem('cn_admin','1'); $('#pass').value=$('#pass2').value=''; return gate();
    }
    const f=load(K.fails,{n:0,until:0});
    if(Date.now()<f.until) return err.textContent=`به‌خاطر تلاش‌های ناموفق، ${Math.ceil((f.until-Date.now())/60000)} دقیقه صبر کنید.`;
    if(await sha(p,c.salt)===c.hash){store(K.fails,{n:0,until:0});sessionStorage.setItem('cn_admin','1');$('#pass').value='';gate()}
    else{f.n++;if(f.n>=5){f.n=0;f.until=Date.now()+5*60000}store(K.fails,f);err.textContent='رمز عبور اشتباه است.'}
  });
  $('#logout').onclick=()=>{sessionStorage.removeItem('cn_admin');gate()};
  $('#chgPass').onclick=async()=>{
    const p=prompt('رمز جدید (حداقل ۶ کاراکتر):');
    if(p&&p.length>=6){const salt=newSalt();store(K.pass,{salt,hash:await sha(p,salt)});alert('رمز تغییر کرد.')}
  };
  ['q','st'].forEach(id=>$('#'+id).addEventListener('input',render));
  setInterval(()=>{if(authed())render()},30000);

  const actions=o=>{
    const b=(a,t,c='')=>`<button class="${c}" data-a="${a}" data-id="${o.id}">${t}</button>`, v=b('view','مشاهده','alt');
    const m={pending:[b('arrive','تأیید حضور با کد'),v,b('noshow','نیامد','danger')],
      arrived:[b('print','چاپ'),v], printing:[b('print','چاپ دوباره','alt'),b('ready','آماده تحویل'),v],
      ready:[b('done','تحویل شد'),v], done:[v], expired:[v], noshow:[v]};
    const blockable=['pending','expired','noshow'].includes(o.status);
    return (m[o.status]||[v]).join('')+(blockable?b('block','مسدود‌کردن شماره','danger'):'')+b('del','حذف','danger');
  };

  function render(){
    expireOverdue();
    const q=digits($('#q').value)||$('#q').value.trim(), st=$('#st').value, now=Date.now(), all=db.orders();
    const l=all.filter(o=>(!st||o.status===st)&&(!q||[o.name,o.phone,o.code].some(x=>x.includes(q))));
    $('#stats').innerHTML=['pending','arrived','printing','ready'].map(s=>`<div><b>${all.filter(o=>o.status===s).length}</b><span>${STATUS[s]}</span></div>`).join('');
    $('#count').textContent=`${l.length} سفارش`;
    $('#list').innerHTML=l.length?l.map(o=>{
      const left=Math.max(0,Math.ceil((o.expiresAt-now)/60000));
      return `<article class="order" data-s="${o.status}">
        <div class="row"><strong>${esc(o.name||'بدون نام')} — کد ${o.code}</strong><span class="badge">${STATUS[o.status]}</span></div>
        <div class="meta">${esc(o.phone)} | ${new Date(o.at).toLocaleString('fa-IR')}${o.status==='pending'?` | <span class="left">مهلت: ${left} دقیقه</span>`:''}</div>
        <div class="meta">${o.copies} نسخه | ${o.color==='color'?'رنگی':'سیاه‌وسفید'} | ${esc(o.size)} | ${o.sides==='2'?'دورو':'یک‌رو'} | ${o.files.length} فایل${o.text?' | دارای متن':''}</div>
        ${o.note?`<div>توضیح: ${esc(o.note)}</div>`:''}
        <div class="acts">${actions(o)}</div></article>`}).join(''):'<p class="empty">سفارشی پیدا نشد.</p>';
    const ph=Object.entries(db.phones());
    $('#blockedList').innerHTML=ph.length?ph.map(([n,r])=>`<div class="row" style="margin:8px 0"><span>${esc(n)} — ${r.strikes} بار نیامده ${r.blocked?'<span class="badge">مسدود</span>':''}</span><button class="alt" data-unblock="${esc(n)}">پاک‌کردن سابقه و رفع مسدودی</button></div>`).join(''):'<p class="meta">موردی ثبت نشده است.</p>';
  }

  const setStatus=(id,s)=>{const l=db.orders();const o=l.find(x=>x.id===id);if(o){o.status=s;db.save(l)}render()};
  $('#blockedList').addEventListener('click',e=>{
    const n=e.target.dataset.unblock; if(!n) return;
    const p=db.phones(); delete p[n]; db.savePhones(p); render();
  });
  $('#list').addEventListener('click',e=>{
    const b=e.target.closest('button'); if(!b) return;
    const o=db.orders().find(x=>x.id===b.dataset.id); if(!o) return;
    switch(b.dataset.a){
      case 'view': return view(o);
      case 'arrive':{
        const c=digits(prompt('کدی که مشتری می‌گوید را وارد کنید:')||'');
        if(c===o.code){const l=db.orders();const x=l.find(y=>y.id===o.id);x.status='arrived';x.arrivedAt=Date.now();db.save(l);render()}
        else if(c) alert('کد اشتباه است.');
        return}
      case 'print': return printOrder(o);
      case 'ready': return setStatus(o.id,'ready');
      case 'done': return setStatus(o.id,'done');
      case 'noshow': if(confirm('ثبت شود که مشتری نیامده؟ این مورد برای شماره او سابقه می‌شود.')){strike(o.phone);setStatus(o.id,'noshow')} return;
      case 'block': if(confirm('این شماره مسدود شود؟')){const p=db.phones();(p[o.phone]||(p[o.phone]={strikes:0,blocked:false})).blocked=true;db.savePhones(p);render()} return;
      case 'del': if(confirm('این سفارش حذف شود؟')){db.save(db.orders().filter(x=>x.id!==o.id));render()} return;
    }
  });

  function view(o){
    $('#dlgBody').innerHTML=`<h2>سفارش ${o.code} — ${esc(o.name)}</h2>
      ${o.text?`<h3>متن</h3><pre class="txt">${esc(o.text)}</pre>`:''}
      ${o.files.map(f=>`<h3>${esc(f.name)}</h3>`+(f.type.startsWith('image/')?`<img src="${f.data}" alt="${esc(f.name)}">`:`<a href="${f.data}" download="${esc(f.name)}">دانلود فایل</a>`)).join('')}`;
    $('#dlg').showModal();
  }
  $('#dlgClose').onclick=()=>$('#dlg').close();

  function printHTML(html){
    const fr=document.createElement('iframe'); fr.style.cssText='position:fixed;width:0;height:0;border:0'; document.body.appendChild(fr);
    fr.srcdoc=`<!doctype html><html lang="fa" dir="rtl"><meta charset="utf-8"><style>body{font:14pt/1.9 Vazirmatn,Tahoma,sans-serif;margin:0}pre{white-space:pre-wrap;font:inherit}img{max-width:100%;page-break-after:always}</style><body>${html}</body></html>`;
    fr.onload=()=>{setTimeout(()=>{fr.contentWindow.focus();fr.contentWindow.print()},300);setTimeout(()=>fr.remove(),60000)};
  }
  async function printOrder(o){
    if(o.status==='pending'||o.status==='expired'||o.status==='noshow') return alert('چاپ فقط بعد از تأیید حضور مشتری ممکن است.');
    if(o.text) printHTML(`<pre>${esc(o.text)}</pre>`);
    const imgs=o.files.filter(f=>f.type.startsWith('image/'));
    if(imgs.length) printHTML(imgs.map(f=>`<img src="${f.data}">`).join(''));
    for(const f of o.files.filter(f=>!f.type.startsWith('image/'))){
      const url=URL.createObjectURL(await (await fetch(f.data)).blob()); window.open(url,'_blank');
    }
    if(o.status==='arrived') setStatus(o.id,'printing');
  }
  gate();
}
